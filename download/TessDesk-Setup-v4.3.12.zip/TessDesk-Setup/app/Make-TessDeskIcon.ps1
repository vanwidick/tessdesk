﻿# Builds the TessDesk app icon: tessdesk.ico (16-256 px, PNG-compressed entries) + tessdesk-512.png.
# Drawn with WPF vectors so every size is crisp. Usage: Make-TessDeskIcon.ps1 -OutDir <folder>
param([string]$OutDir = (Split-Path -Parent $MyInvocation.MyCommand.Path))
Add-Type -AssemblyName PresentationCore, WindowsBase
$ErrorActionPreference = 'Stop'

function New-IconPng {
    param([int]$Size)
    $s = $Size / 512.0
    $dv = New-Object System.Windows.Media.DrawingVisual
    $dc = $dv.RenderOpen()
    $dc.PushTransform((New-Object System.Windows.Media.ScaleTransform $s, $s))
    # rounded dark tile
    $bg = New-Object System.Windows.Media.LinearGradientBrush ([System.Windows.Media.Color]::FromRgb(0x24, 0x24, 0x28)), ([System.Windows.Media.Color]::FromRgb(0x06, 0x06, 0x08)), 90.0
    $dc.DrawRoundedRectangle($bg, $null, (New-Object System.Windows.Rect 8, 8, 496, 496), 112, 112)
    $red = [System.Windows.Media.Color]::FromRgb(0xE8, 0x21, 0x27)
    # battery-gauge ring (open at the bottom), Tesla red
    $pen = New-Object System.Windows.Media.Pen (New-Object System.Windows.Media.SolidColorBrush $red), 38
    $pen.StartLineCap = 'Round'; $pen.EndLineCap = 'Round'
    $cx = 256.0; $cy = 262.0; $rad = 168.0
    $a0 = (90 + 38) * [math]::PI / 180; $a1 = (90 - 38 + 360) * [math]::PI / 180
    $p0 = New-Object System.Windows.Point ($cx + $rad * [math]::Cos($a0)), ($cy + $rad * [math]::Sin($a0))
    $p1 = New-Object System.Windows.Point ($cx + $rad * [math]::Cos($a1)), ($cy + $rad * [math]::Sin($a1))
    $fig = New-Object System.Windows.Media.PathFigure
    $fig.StartPoint = $p0
    $arc = New-Object System.Windows.Media.ArcSegment $p1, (New-Object System.Windows.Size $rad, $rad), 0, $true, ([System.Windows.Media.SweepDirection]::Clockwise), $true
    $fig.Segments.Add($arc)
    $geo = New-Object System.Windows.Media.PathGeometry
    $geo.Figures.Add($fig)
    $dc.DrawGeometry($null, $pen, $geo)
    # white lightning bolt
    $bolt = [System.Windows.Media.Geometry]::Parse('M 282,128 L 186,280 L 248,280 L 228,392 L 328,226 L 266,226 Z')
    $dc.DrawGeometry([System.Windows.Media.Brushes]::White, $null, $bolt)
    $dc.Pop()
    $dc.Close()
    $bmp = New-Object System.Windows.Media.Imaging.RenderTargetBitmap $Size, $Size, 96, 96, ([System.Windows.Media.PixelFormats]::Pbgra32)
    $bmp.Render($dv)
    $enc = New-Object System.Windows.Media.Imaging.PngBitmapEncoder
    $enc.Frames.Add([System.Windows.Media.Imaging.BitmapFrame]::Create($bmp))
    $ms = New-Object System.IO.MemoryStream
    $enc.Save($ms)
    return ,$ms.ToArray()
}

if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
[System.IO.File]::WriteAllBytes((Join-Path $OutDir 'tessdesk-512.png'), (New-IconPng 512))
[System.IO.File]::WriteAllBytes((Join-Path $OutDir 'tessdesk-256.png'), (New-IconPng 256))

$sizes = 16, 24, 32, 48, 64, 128, 256
$pngs = @(); foreach ($sz in $sizes) { $pngs += ,(New-IconPng $sz) }
$ms = New-Object System.IO.MemoryStream
$bw = New-Object System.IO.BinaryWriter $ms
$bw.Write([uint16]0); $bw.Write([uint16]1); $bw.Write([uint16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
for ($i = 0; $i -lt $sizes.Count; $i++) {
    $sz = $sizes[$i]; $b = if ($sz -ge 256) { 0 } else { $sz }
    $bw.Write([byte]$b); $bw.Write([byte]$b); $bw.Write([byte]0); $bw.Write([byte]0)
    $bw.Write([uint16]1); $bw.Write([uint16]32)
    $bw.Write([uint32]$pngs[$i].Length); $bw.Write([uint32]$offset)
    $offset += $pngs[$i].Length
}
foreach ($p in $pngs) { $bw.Write($p) }
$bw.Flush()
[System.IO.File]::WriteAllBytes((Join-Path $OutDir 'tessdesk.ico'), $ms.ToArray())
Write-Output ('Icon=' + (Join-Path $OutDir 'tessdesk.ico') + ' sizes=' + ($sizes -join ','))
