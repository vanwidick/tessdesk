﻿#Requires -Version 5.1
# TessDesk uninstaller: stops TessDesk, removes its reminder + Alexa announcement tasks and shortcuts, and deletes this install folder
# (tokens incl. Voice Monkey, settings, App Password and reminders are all inside it). To fully revoke access, also delete the API token in the Tessie app.
param([switch]$Quiet, [switch]$KeepFiles)
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$script = Join-Path $dir 'TessDesk.ps1'
if (-not $Quiet) {
    Add-Type -AssemblyName PresentationFramework
    $a = [System.Windows.MessageBox]::Show("Remove TessDesk from this PC?`n`nFolder: $dir", 'Uninstall TessDesk', 'YesNo', 'Question')
    if ($a -ne 'Yes') { exit 0 }
}
Get-CimInstance Win32_Process -Filter "name='powershell.exe'" | Where-Object { $_.CommandLine -like ('*' + $script + '*') } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
# remove this install's scheduled Alexa announcement tasks (v4.2, "TessDesk Announce <type> <n>")
try {
    Get-ScheduledTask -TaskName 'TessDesk Announce *' -ErrorAction SilentlyContinue | Where-Object { $_.Description -like ('*Install: ' + $dir + '*') } |
        ForEach-Object { Unregister-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -Confirm:$false -ErrorAction SilentlyContinue }
} catch {}
# remove this install's one-time reminder tasks ("TessDesk Reminder <id>", description names this folder)
try {
    Get-ScheduledTask -TaskName 'TessDesk Reminder *' -ErrorAction SilentlyContinue | Where-Object { $_.Description -like ('*Install: ' + $dir + '*') } |
        ForEach-Object { Unregister-ScheduledTask -TaskName $_.TaskName -TaskPath $_.TaskPath -Confirm:$false -ErrorAction SilentlyContinue }
} catch {}
$w = New-Object -ComObject WScript.Shell
foreach ($folder in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Startup'))) {
    $lnk = Join-Path $folder 'TessDesk.lnk'
    if (Test-Path -LiteralPath $lnk) {
        # only remove shortcuts that point at THIS install
        if ($w.CreateShortcut($lnk).Arguments -like ('*' + $script + '*')) { Remove-Item -LiteralPath $lnk -Force }
    }
}
if (-not $KeepFiles) {
    # delete the folder after this script exits (it is running from inside it)
    Start-Process -FilePath 'cmd.exe' -ArgumentList ('/c ping -n 3 127.0.0.1 >nul & rmdir /s /q "' + $dir + '"') -WindowStyle Hidden
}
if (-not $Quiet) { [System.Windows.MessageBox]::Show('TessDesk was removed.', 'Uninstall TessDesk') | Out-Null }
