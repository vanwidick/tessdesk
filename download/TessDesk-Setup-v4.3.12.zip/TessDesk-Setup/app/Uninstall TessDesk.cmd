@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0TessDesk-Uninstall.ps1" %*
