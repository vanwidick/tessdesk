﻿#Requires -Version 5.1
<#
  TessDesk-Setup v4.3 - shows the notice/permissions, then installs the TessDesk desktop widget for the current Windows user.
  Double-click TessDesk-Setup.cmd. A small form asks for your name, Tessie API token, car, electricity rates
  and charging efficiency, checks the token with Tessie, then installs to %LOCALAPPDATA%\TessDesk.

  Advanced / testing switches:
    -DryRun          validate and show what would be written; change nothing
    -NoGui           no form; use -Name -TokenFile -Vin -Preset/-rate parameters instead
    -InstallDir      install somewhere else (default %LOCALAPPDATA%\TessDesk)
    -NoShortcuts     skip Desktop/Startup shortcuts       -NoLaunch   don't start TessDesk afterwards
    -SkipValidation  don't call Tessie (offline test)      -GuiSelfTest build the form, don't show it, exit
    -AcceptTerms -AllowCommands -AllowReminders     notice + permissions for -NoGui installs
    -RemindChannel email|text|both -RemindEmail -RemindPhone -Carrier verizon|... -SmtpPreset gmail|... -SmtpUser -SmtpPasswordFile
    -ReminderDryRun  reminders only print/log, never send   -TestReminder  test reminder (with -DryRun: print only)
    -AllowAnnouncements -VoiceMonkeyDevice <id> -VoiceMonkeyTokenFile <file>   Alexa announcements via Voice Monkey (optional)
    -TestAnnouncement  test announcement (with -DryRun: print only)
#>
param(
    [string]$InstallDir = (Join-Path $env:LOCALAPPDATA 'TessDesk'),
    [switch]$DryRun,
    [switch]$NoGui,
    [switch]$NoShortcuts,
    [switch]$NoLaunch,
    [switch]$SkipValidation,
    [switch]$GuiSelfTest,
    [string]$Name,
    [string]$TokenFile,
    [string]$Vin,
    [ValidateSet('pso', 'custom')][string]$Preset = 'custom',
    [double]$OvernightRate = 0.10,
    [int]$OvernightStart = 23,
    [int]$OvernightEnd = 6,
    [double]$DaytimeRate = 0.13,
    [double]$FuelAdder = 0.0,
    [switch]$PeakEnabled,
    [double]$PeakRate = 0.0,
    [int]$PeakStart = 14,
    [int]$PeakEnd = 19,
    [string]$PeakMonths = '6-10',
    [double]$EfficiencyPct = 90,
    # v4.1 notice / permissions (-NoGui needs -AcceptTerms; reading vehicle data is always required)
    [switch]$AcceptTerms,
    [switch]$AllowCommands,
    [switch]$AllowReminders,
    # v4.1 reminders (sent later through YOUR email account; texts via the carrier's email-to-SMS gateway)
    [ValidateSet('email', 'text', 'both')][string]$RemindChannel = 'email',
    [string]$RemindEmail,
    [string]$RemindPhone,
    [string]$Carrier = '',
    [ValidateSet('gmail', 'outlook', 'yahoo', 'icloud', 'custom')][string]$SmtpPreset = 'gmail',
    [string]$SmtpHost,
    [int]$SmtpPort = 0,
    [string]$SmtpUser,
    [string]$SmtpPasswordFile,
    [switch]$ReminderDryRun,   # reminders compose + log only, never send (testing)
    [switch]$TestReminder,     # -NoGui: send (or with -DryRun, just print) a test reminder, then exit
    # v4.2 Connected apps: Alexa announcements through Voice Monkey (token read from a file, stored with DPAPI)
    [switch]$AllowAnnouncements,
    [string]$VoiceMonkeyDevice,
    [string]$VoiceMonkeyTokenFile,
    [switch]$TestAnnouncement
)
$ErrorActionPreference = 'Stop'
$SetupVersion = '4.3'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $here 'app'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}

# Van's PSO RSEV (Oklahoma) plan, offered as an example preset.
$PsoPreset = [ordered]@{
    plan = 'PSO RSEV (Oklahoma) - example'
    fuelAdderPerKwh = 0.031872
    overnight = [ordered]@{ rate = 0.030451; startHour = 23; endHour = 6 }
    daytime = [ordered]@{ rate = 0.061045; seasonalRate = 0.084497; seasonalMonths = @(6, 7, 8, 9, 10) }
    peak = [ordered]@{ enabled = $true; rate = 0.248475; startHour = 14; endHour = 19; months = @(6, 7, 8, 9, 10); weekdaysOnly = $true }
}

function Write-Step { param([string]$m) Write-Output ('[TessDesk-Setup] ' + $m) }

function ConvertTo-MonthList {
    param([string]$s)
    $out = @()
    foreach ($part in ($s -split '[,; ]+' | Where-Object { $_ })) {
        if ($part -match '^(\d{1,2})-(\d{1,2})$') { $a = [int]$Matches[1]; $b = [int]$Matches[2]; for ($m = $a; $m -le $b; $m++) { $out += $m } }
        elseif ($part -match '^\d{1,2}$') { $out += [int]$part }
        else { throw "Months must look like 6-10 or 6,7,8 (got '$part')" }
    }
    $out = @($out | Where-Object { $_ -ge 1 -and $_ -le 12 } | Sort-Object -Unique)
    return $out
}

# ---------------- Tessie check ----------------
function Get-TessieVehicles {
    param([string]$Secret)
    $h = @{ Authorization = ('Bearer ' + $Secret); Accept = 'application/json' }
    $r = Invoke-RestMethod -Uri 'https://api.tessie.com/vehicles?only_active=false' -Headers $h -Method Get -TimeoutSec 20 -UseBasicParsing
    $list = @()
    foreach ($v in @($r.results)) {
        if ($null -eq $v -or -not $v.vin) { continue }
        $nm = [string]$v.last_state.display_name
        if (-not $nm) { $nm = 'Tesla' }
        $list += [pscustomobject]@{ vin = [string]$v.vin; name = $nm; active = [bool]$v.is_active; label = ('{0}  ·  {1}' -f $nm, $v.vin) }
    }
    return $list
}

# ---------------- Build config ----------------
function New-TessDeskConfig {
    param([string]$DisplayName, [string]$CarVin, $Rates, [double]$Eff, $Consent = $null, $Rem = $null, $Ann = $null)
    if ($Eff -gt 1.5) { $Eff = $Eff / 100.0 }
    $onStart = [int]$Rates.overnight.startHour
    return [ordered]@{
        displayName = $DisplayName
        tokenFile = 'tessie.token'
        vin = $CarVin
        timeZoneId = ([TimeZoneInfo]::Local.Id)
        efficiency = [math]::Round($Eff, 3)
        rates = $Rates
        overnightWindow = [ordered]@{ startHour = $onStart; endHour = 11 }
        placement = [ordered]@{ rightOffset = 388; top = 48 }
        fallbackJson = 'tesla-overnight-cost.json'
        defaultTheme = 'tessie'
        controls = [ordered]@{ enabled = $true; dryRun = $false }
        tires = [ordered]@{ yellowPct = 5; redPct = 10; maxPsiNoRec = 48; minPsiNoRec = 38 }
        consent = $Consent
        reminders = $Rem
        climate = [ordered]@{ heatTempF = 82 }
        announce = [ordered]@{ actions = $false; device = $(if ($null -ne $Ann) { [string]$Ann.device } else { '' }); dryRun = $false; schedules = [ordered]@{} }
    }
}

# ---------------- v4.1: notice, help links, reminders ----------------
$NoticeTitle = 'Before you install: notice, privacy and permissions'
$NoticeText = @"
TessDesk is an unofficial app. It is not made by, affiliated with, or endorsed by Tesla or Tessie.

• It uses your Tessie API token to READ vehicle data (location, battery, charging, tires, lock and climate state) and, only when you press a control, to SEND commands (lock/unlock, windows, climate, charge limit).
• Your token and settings are stored only on this PC (the token and email password are protected with Windows DPAPI) and the token is sent only to api.tessie.com.
• Alexa announcements (optional, Connected apps): the text of each announcement (e.g. charging cost, tire pressures, battery, lock and window state) is sent to Voice Monkey and Amazon so your Echo can speak it. Off unless you set it up and agree.
• Reminders are sent through your own email account or your carrier's email-to-text gateway. Nothing goes to the TessDesk author.
• Costs shown are estimates based on the rates you enter, not your utility bill.
• Commands can wake the car and use a little battery. Use the controls only when it is safe and legal.
• No warranty. You use TessDesk at your own risk. Tessie's Terms of Service apply to your Tessie account and token.
• To revoke access: delete the API token in the Tessie app (Settings → API). To uninstall: double-click "Uninstall TessDesk.cmd" in the TessDesk folder (%LOCALAPPDATA%\TessDesk); it also removes TessDesk reminder tasks.
"@
$HelpLinks = @(
    @('Sign up for Tessie', 'https://www.tessie.com', 'No Tessie account? Tessie is a paid service that connects to your Tesla.'),
    @('Get your API token', 'https://dash.tessie.com/settings/api', 'After signing up: Tessie app → Settings → API (or this page on the web).'),
    @('Create a Gmail account', 'https://accounts.google.com/signup', 'No Gmail? Free. Used only to send your own reminders.'),
    @('Turn on 2-Step Verification', 'https://myaccount.google.com/signinoptions/two-step-verification', 'Google requires it before you can make an App Password.'),
    @('Make a Gmail App Password', 'https://myaccount.google.com/apppasswords', 'A 16-letter password just for TessDesk reminders.'),
    @('How App Passwords work', 'https://support.google.com/accounts/answer/185833', 'Google help article.')
)
# Carrier email-to-SMS gateways, with honest status (checked Oct 2026).
$Carriers = [ordered]@{
    verizon   = @('Verizon', 'vtext.com', 'Works for now; Verizon is ending it by Mar 31, 2027')
    visible   = @('Visible (Verizon)', 'vzwpix.com', 'Verizon network; same shutdown risk')
    att       = @('AT&T', 'txt.att.net', 'AT&T shut this down in June 2025: will NOT deliver')
    tmobile   = @('T-Mobile / Mint / Metro', 'tmomail.net', 'Reported not delivering since late 2024: unreliable')
    uscellular = @('UScellular', 'email.uscc.net', 'May still work')
    googlefi  = @('Google Fi', 'msg.fi.google.com', 'Reported working for Fi users')
    cricket   = @('Cricket', 'mms.cricketwireless.net', 'AT&T network: likely will not deliver')
    boost     = @('Boost Mobile', 'sms.myboostmobile.com', 'Unreliable')
}
$SmtpPresets = [ordered]@{
    gmail   = @('Gmail (App Password)', 'smtp.gmail.com', 587, 'Needs 2-Step Verification + an App Password (links on the left of the token step).')
    outlook = @('Outlook.com / Hotmail', 'smtp-mail.outlook.com', 587, 'Microsoft has been turning off password sign-in for SMTP; may not work.')
    yahoo   = @('Yahoo Mail (App Password)', 'smtp.mail.yahoo.com', 587, 'Yahoo Account Security → Generate app password.')
    icloud  = @('iCloud Mail (app-specific password)', 'smtp.mail.me.com', 587, 'appleid.apple.com → Sign-In and Security → App-Specific Passwords.')
    custom  = @('Custom SMTP server', '', 587, 'Your provider''s SMTP host and port (STARTTLS).')
}
function New-ConsentRecord {
    param([bool]$Commands, [bool]$Reminders, [string]$Via, [bool]$Announcements = $false)
    return [ordered]@{ version = $SetupVersion; agreed = $true; agreedAt = (Get-Date).ToString('yyyy-MM-ddTHH:mm:sszzz'); via = $Via
        readVehicleData = $true; sendCommands = $Commands; reminders = $Reminders; announcements = $Announcements }
}
function New-ReminderConfig {
    param([bool]$Enabled, [string]$Channel, [string]$Email, [string]$Phone, [string]$CarrierKey, [string]$GatewayOverride, [string]$PresetKey, [string]$SHost, [int]$SPort, [string]$SUser, [bool]$Dry)
    $gw = $GatewayOverride; if (-not $gw -and $CarrierKey -and $Carriers.Contains($CarrierKey)) { $gw = $Carriers[$CarrierKey][1] }
    if (-not $PresetKey) { $PresetKey = 'gmail' }
    $ps = $SmtpPresets[$PresetKey]
    if (-not $SHost) { $SHost = $ps[1] }; if ($SPort -le 0) { $SPort = [int]$ps[2] }
    return [ordered]@{ enabled = $Enabled; channel = $Channel; email = $Email; phone = $Phone; carrier = $CarrierKey; carrierGateway = $gw
        smtp = [ordered]@{ preset = $PresetKey; host = $SHost; port = $SPort; ssl = $true; user = $SUser; from = $SUser }
        smtpSecretFile = 'smtp.secret'; dryRun = $Dry }
}
function Test-ReminderConfig {
    param($Rem, [bool]$HavePassword)
    if (-not $Rem.enabled) { return }
    if ($Rem.channel -in 'email', 'both' -and $Rem.email -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') { throw 'Reminders: enter a valid email address.' }
    if ($Rem.channel -in 'text', 'both') {
        if ((($Rem.phone -replace '\D', '').Length) -lt 10) { throw 'Reminders: enter a 10-digit mobile number.' }
        if (-not $Rem.carrierGateway) { throw 'Reminders: pick your carrier.' }
    }
    if (-not $Rem.smtp.host) { throw 'Reminders: enter the SMTP server.' }
    if ($Rem.smtp.user -notmatch '@') { throw 'Reminders: enter the email account that sends the reminders.' }
    if (-not $HavePassword) { throw 'Reminders: enter the App Password for the sending account.' }
}
# DPAPI (CurrentUser): the encrypted string can only be decrypted by this Windows account on this PC.
function Protect-Text { param([string]$Text) return (ConvertTo-SecureString -String $Text -AsPlainText -Force | ConvertFrom-SecureString) }
# Test reminder: temporary config + DPAPI password in %TEMP%, runs app\TessDesk-Remind.ps1 -Test (with -DryRun: print only).
function Invoke-TestReminder {
    param($Rem, [string]$Password, [bool]$Dry)
    $tmp = Join-Path $env:TEMP ('tessdesk-testrem-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
    New-Item -ItemType Directory -Path $tmp -Force | Out-Null
    try {
        $r2 = [ordered]@{}; foreach ($k in $Rem.Keys) { $r2[$k] = $Rem[$k] }; $r2.enabled = $true
        ([ordered]@{ reminders = $r2; consent = [ordered]@{ reminders = $true } } | ConvertTo-Json -Depth 6) | Set-Content -LiteralPath (Join-Path $tmp 'config.json') -Encoding UTF8
        if ($Password) { Protect-Text $Password | Set-Content -LiteralPath (Join-Path $tmp 'smtp.secret') -Encoding ASCII }
        $args2 = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $payload 'TessDesk-Remind.ps1'), '-Test', '-ConfigPath', (Join-Path $tmp 'config.json'))
        if ($Dry) { $args2 += '-DryRun' }
        $out = & powershell.exe @args2 2>&1 | ForEach-Object { [string]$_ }
        return [pscustomobject]@{ ok = ($LASTEXITCODE -eq 0); lines = @($out) }
    } finally { Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue }
}

function New-CustomRates {
    param([double]$On, [int]$OnS, [int]$OnE, [double]$Day, [double]$Fuel, [bool]$PkOn, [double]$Pk, [int]$PkS, [int]$PkE, [string]$PkM)
    foreach ($x in @($On, $Day, $Fuel, $Pk)) { if ($x -lt 0 -or $x -gt 5) { throw 'Rates must be in $ per kWh, for example 0.12' } }
    foreach ($x in @($OnS, $OnE, $PkS, $PkE)) { if ($x -lt 0 -or $x -gt 23) { throw 'Hours must be 0-23' } }
    $months = @(6, 7, 8, 9, 10); if ($PkM) { $months = ConvertTo-MonthList $PkM }
    return [ordered]@{
        plan = 'custom'
        fuelAdderPerKwh = $Fuel
        overnight = [ordered]@{ rate = $On; startHour = $OnS; endHour = $OnE }
        daytime = [ordered]@{ rate = $Day; seasonalRate = $null; seasonalMonths = @() }
        peak = [ordered]@{ enabled = $PkOn; rate = $Pk; startHour = $PkS; endHour = $PkE; months = $months; weekdaysOnly = $true }
    }
}

# ---------------- Install ----------------
function Protect-CurrentUserOnly {
    param([string]$Path)
    $acl = New-Object System.Security.AccessControl.FileSecurity
    $acl.SetAccessRuleProtection($true, $false)
    $me = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
    $acl.SetOwner($me)
    $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($me, 'FullControl', 'Allow')))
    [System.IO.File]::SetAccessControl($Path, $acl)
}

function New-Shortcut {
    param([string]$LinkPath, [string]$Script, [string]$Icon, [string]$WorkDir)
    $w = New-Object -ComObject WScript.Shell
    $s = $w.CreateShortcut($LinkPath)
    $s.TargetPath = (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe')
    $s.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + $Script + '"'
    $s.WorkingDirectory = $WorkDir
    $s.WindowStyle = 7
    $s.Description = 'TessDesk - live Tesla charging cost'
    if (Test-Path -LiteralPath $Icon) { $s.IconLocation = $Icon + ',0' }
    $s.Save()
}

# ---------------- v4.2: Connected apps (Voice Monkey → Alexa) ----------------
$VmApi = 'https://api-v3.voicemonkey.io'
$AnnDisclosure = 'I understand: the text of each announcement (for example charging cost, tire pressures, battery, lock and window state) is sent to Voice Monkey and Amazon (Alexa) so it can be spoken on my Echo. TessDesk sends nothing else there.'
function Test-VoiceMonkey {
    # GET /devices (Bearer token): checks the token and that the speaker device exists. Sends no announcement.
    param([string]$Tok, [string]$Dev)
    if (-not $Tok) { throw 'Paste your Voice Monkey API token (app.voicemonkey.io/tokens).' }
    $r = Invoke-RestMethod -Uri ($VmApi + '/devices') -Headers @{ Authorization = ('Bearer ' + $Tok) } -Method Get -TimeoutSec 15 -UseBasicParsing
    $sp = @($r.data | Where-Object { $_.capability -eq 'speakers' })
    $hit = @($sp | Where-Object { $_.id -eq $Dev -or $_.name -eq $Dev })
    if ($Dev -and $hit.Count -gt 0) { return ('Token OK · speaker "' + $hit[0].name + '" (' + $hit[0].id + ') found') }
    return ('Token OK · speakers: ' + ((@($sp | ForEach-Object { $_.id }) -join ', ')) + $(if ($Dev) { ' · "' + $Dev + '" NOT found' } else { '' }))
}
function Invoke-TestAnnouncement {
    param([string]$Tok, [string]$Dev, [bool]$Dry)
    $txt = 'This is a TessDesk test announcement. Alexa announcements are working.'
    if ($Dry) { return ('DRY RUN (nothing sent) -> ' + $Dev + ': ' + $txt) }
    if (-not $Tok -or -not $Dev) { throw 'Enter the Voice Monkey token and the speaker device first.' }
    $body = @{ token = $Tok; device = $Dev; speech = $txt } | ConvertTo-Json -Compress
    Invoke-RestMethod -Uri ($VmApi + '/announce') -Method Post -ContentType 'application/json' -Body $body -TimeoutSec 20 -UseBasicParsing | Out-Null
    return ('Sent to ' + $Dev + '. You should hear it now.')
}

function Install-TessDesk {
    param([string]$DisplayName, [string]$Secret, [string]$CarVin, $Rates, [double]$Eff, $Consent, $Rem = $null, [string]$SmtpPassword = '', $Ann = $null)
    $log = New-Object System.Collections.Generic.List[string]
    foreach ($f in 'TessDesk.ps1', 'TessDesk-Remind.ps1', 'TessDesk-Announce.ps1', 'TessDesk-Speakers.ps1', 'PRIVACY.md', 'tessdesk.ico', 'TessDesk-Uninstall.ps1') {
        if (-not (Test-Path -LiteralPath (Join-Path $payload $f))) { throw "Setup files are missing ($f). Unzip the whole folder first." }
    }
    if (-not $DisplayName) { throw 'Please enter your name.' }
    if (-not $Secret) { throw 'Please paste your Tessie API token.' }
    if ($null -eq $Consent -or -not $Consent.agreed -or -not $Consent.readVehicleData) { throw 'Please read the notice and agree (and allow reading vehicle data) before installing.' }
    if ($null -eq $Rem) { $Rem = New-ReminderConfig $false 'email' '' '' '' '' 'gmail' '' 0 '' $false }
    if (-not $Consent.reminders) { $Rem.enabled = $false }
    Test-ReminderConfig $Rem ([bool]$SmtpPassword)
    if ($null -ne $Ann -and -not $Consent.announcements) { $Ann = $null }
    $cfg = New-TessDeskConfig $DisplayName $CarVin $Rates $Eff $Consent $Rem $Ann
    $script = Join-Path $InstallDir 'TessDesk.ps1'
    $icon = Join-Path $InstallDir 'tessdesk.ico'
    $desktop = [Environment]::GetFolderPath('Desktop'); $startup = [Environment]::GetFolderPath('Startup')

    if ($DryRun) {
        $log.Add('DRY RUN - nothing was changed.')
        $log.Add('Would install to: ' + $InstallDir)
        foreach ($f in Get-ChildItem -LiteralPath $payload -File) { $log.Add('  copy ' + $f.Name) }
        $log.Add('  write config.json:')
        foreach ($line in (($cfg | ConvertTo-Json -Depth 8) -split "`r?`n")) { $log.Add('    ' + $line) }
        $log.Add(('  write tessie.token.dpapi (token {0} characters, encrypted with Windows DPAPI for {1})' -f $Secret.Length, [Environment]::UserName))
        if ($Rem.enabled) { $log.Add('  write smtp.secret (App Password encrypted with Windows DPAPI)') }
        if ($null -ne $Ann -and $Ann.token) { $log.Add(('  write voicemonkey.token.dpapi (Voice Monkey token, Windows DPAPI) · speaker {0}' -f $Ann.device)) }
        if (-not $NoShortcuts) { $log.Add('  shortcut: ' + (Join-Path $desktop 'TessDesk.lnk')); $log.Add('  shortcut: ' + (Join-Path $startup 'TessDesk.lnk')) }
        if (-not $NoLaunch) { $log.Add('  launch: ' + $script) }
        return $log
    }

    # stop a running copy from this folder
    Get-CimInstance Win32_Process -Filter "name='powershell.exe'" | Where-Object { $_.CommandLine -like ('*' + $script + '*') } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    if (-not (Test-Path -LiteralPath $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
    foreach ($f in Get-ChildItem -LiteralPath $payload -File) {
        Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $InstallDir $f.Name) -Force
        try { Unblock-File -LiteralPath (Join-Path $InstallDir $f.Name) } catch {}
    }
    $log.Add('Copied app files to ' + $InstallDir)
    ($cfg | ConvertTo-Json -Depth 8) | Set-Content -LiteralPath (Join-Path $InstallDir 'config.json') -Encoding UTF8
    $log.Add('Wrote config.json')
    # Token: Windows DPAPI (ConvertFrom-SecureString), never plain text. An older plain tessie.token is removed.
    $tf = Join-Path $InstallDir 'tessie.token.dpapi'
    Protect-Text $Secret.Trim() | Set-Content -LiteralPath $tf -Encoding ASCII
    Protect-CurrentUserOnly $tf
    $plain = Join-Path $InstallDir 'tessie.token'
    if (Test-Path -LiteralPath $plain) { Remove-Item -LiteralPath $plain -Force; $log.Add('Removed the old plain-text tessie.token') }
    $log.Add('Wrote tessie.token.dpapi (encrypted with Windows DPAPI, readable by ' + [Environment]::UserName + ' only)')
    if ($Rem.enabled -and $SmtpPassword) {
        $sf = Join-Path $InstallDir 'smtp.secret'
        Protect-Text $SmtpPassword | Set-Content -LiteralPath $sf -Encoding ASCII
        Protect-CurrentUserOnly $sf
        $log.Add('Wrote smtp.secret (App Password, Windows DPAPI)')
    }
    if ($null -ne $Ann -and $Ann.token) {
        $vf = Join-Path $InstallDir 'voicemonkey.token.dpapi'
        Protect-Text $Ann.token.Trim() | Set-Content -LiteralPath $vf -Encoding ASCII
        Protect-CurrentUserOnly $vf
        $log.Add('Wrote voicemonkey.token.dpapi (Voice Monkey token, Windows DPAPI) · speaker ' + $Ann.device + '. Turn on the ALEXA switch and pick schedules in the widget.')
    }
    $log.Add(('Consent saved {0}: read vehicle data = yes, commands = {1}, reminders = {2}' -f $Consent.agreedAt, $(if ($Consent.sendCommands) { 'yes' } else { 'no' }), $(if ($Consent.reminders) { 'yes' } else { 'no' })))
    if (-not $NoShortcuts) {
        New-Shortcut (Join-Path $desktop 'TessDesk.lnk') $script $icon $InstallDir
        New-Shortcut (Join-Path $startup 'TessDesk.lnk') $script $icon $InstallDir
        $log.Add('Created Desktop and Startup shortcuts')
    }
    if (-not $NoLaunch) {
        Start-Process -FilePath 'powershell.exe' -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', $script) -WindowStyle Hidden
        $log.Add('Started TessDesk')
    }
    return $log
}

function Read-SecretFile {
    param([string]$Path)
    if (-not $Path) { return $null }
    $raw = Get-Content -LiteralPath $Path -Raw
    $line = @($raw -split "`r?`n" | Where-Object { $_.Trim() }) | Select-Object -First 1
    if (-not $line) { return $null }
    return (($line.Trim().Trim([char]0xFEFF)) -replace '^(?i)bearer\s+', '')
}

# ---------------- Setup form ----------------
function Show-SetupForm {
    Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
    [xml]$fx = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="TessDesk Setup" Width="540" Height="820" WindowStartupLocation="CenterScreen" ResizeMode="CanMinimize"
        Background="#FF101010" FontFamily="Segoe UI" FontSize="13">
  <Window.Resources>
    <Style TargetType="TextBlock"><Setter Property="Foreground" Value="#FFDDDDDD"/></Style>
    <Style x:Key="Hint" TargetType="TextBlock"><Setter Property="Foreground" Value="#FF8A8A8A"/><Setter Property="FontSize" Value="11"/><Setter Property="TextWrapping" Value="Wrap"/></Style>
    <Style x:Key="Hdr" TargetType="TextBlock"><Setter Property="Foreground" Value="#FFE82127"/><Setter Property="FontWeight" Value="Bold"/><Setter Property="FontSize" Value="12"/><Setter Property="Margin" Value="0,14,0,4"/></Style>
    <Style TargetType="TextBox"><Setter Property="Padding" Value="4,3"/><Setter Property="Margin" Value="0,2,0,0"/></Style>
  </Window.Resources>
  <Grid>
  <DockPanel x:Name="NoticePage" Margin="20,14,20,14">
    <StackPanel DockPanel.Dock="Top">
      <TextBlock Text="TESSDESK SETUP" Foreground="#FFE82127" FontWeight="Bold" FontSize="18"/>
      <TextBlock x:Name="NoticeTitle" FontWeight="Bold" FontSize="14" Margin="0,6,0,6"/>
    </StackPanel>
    <StackPanel DockPanel.Dock="Bottom" Margin="0,10,0,0">
      <CheckBox x:Name="AgreeChk" Content="I have read this notice and I agree" Foreground="#FFFFFFFF" FontWeight="Bold" Margin="0,4,0,6"/>
      <CheckBox x:Name="PermRead" Content="Allow TessDesk to read vehicle data from Tessie (required)" Foreground="#FFDDDDDD" IsChecked="True" Margin="0,2,0,2"/>
      <CheckBox x:Name="PermCmd" Content="Allow TessDesk to send vehicle commands (optional; off = controls disabled)" Foreground="#FFDDDDDD" IsChecked="True" Margin="0,2,0,2"/>
      <CheckBox x:Name="PermRem" Content="Allow reminders by email/text (optional)" Foreground="#FFDDDDDD" IsChecked="True" Margin="0,2,0,2"/>
      <TextBlock x:Name="NoticeMsg" Style="{StaticResource Hint}" Text="Check &quot;I agree&quot; and the required permission to continue." Margin="0,6,0,6"/>
      <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
        <Button x:Name="NoticeCancel" Content="Cancel" Width="90" Height="30" Margin="0,0,8,0"/>
        <Button x:Name="ContinueBtn" Content="Continue" Width="150" Height="30" IsEnabled="False" Background="#FFE82127" Foreground="White" BorderThickness="0" FontWeight="SemiBold"/>
      </StackPanel>
    </StackPanel>
    <ScrollViewer VerticalScrollBarVisibility="Auto">
      <TextBlock x:Name="NoticeBody" TextWrapping="Wrap" Foreground="#FFCCCCCC" FontSize="12.5" LineHeight="19"/>
    </ScrollViewer>
  </DockPanel>
  <DockPanel x:Name="FormPage" Margin="20,14,20,14" Visibility="Collapsed">
    <StackPanel DockPanel.Dock="Top">
      <TextBlock Text="TESSDESK SETUP" Foreground="#FFE82127" FontWeight="Bold" FontSize="18"/>
      <TextBlock Style="{StaticResource Hint}" Text="Live Tesla charging cost on your desktop, powered by your Tessie account. Takes about a minute."/>
    </StackPanel>
    <StackPanel DockPanel.Dock="Bottom" Orientation="Vertical" Margin="0,10,0,0">
      <TextBlock x:Name="Msg" Style="{StaticResource Hint}" Text="" Margin="0,0,0,8"/>
      <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
        <Button x:Name="CancelBtn" Content="Cancel" Width="90" Height="30" Margin="0,0,8,0"/>
        <Button x:Name="InstallBtn" Content="Install TessDesk" Width="150" Height="30" IsEnabled="False" Background="#FFE82127" Foreground="White" BorderThickness="0" FontWeight="SemiBold"/>
      </StackPanel>
    </StackPanel>
    <ScrollViewer VerticalScrollBarVisibility="Auto">
      <StackPanel>
        <TextBlock Style="{StaticResource Hdr}" Text="1. YOUR NAME"/>
        <TextBox x:Name="NameBox"/>
        <TextBlock Style="{StaticResource Hint}" Text="Shown as 'Logged in as ...' at the top of the widget."/>

        <TextBlock Style="{StaticResource Hdr}" Text="2. TESSIE API TOKEN"/>
        <Grid>
          <Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
          <PasswordBox x:Name="TokBox" Padding="4,3" Margin="0,2,8,0"/>
          <Button x:Name="CheckBtn" Grid.Column="1" Content="Check token" Width="100" Height="26"/>
        </Grid>
        <TextBlock Style="{StaticResource Hint}" Text="Tessie app → Settings → API. Copy the access token and paste it here. It is stored only on this PC, encrypted with Windows DPAPI for your account."/>
        <TextBlock x:Name="TokStatus" Style="{StaticResource Hint}" Text="" Foreground="#FFAAAAAA"/>
        <Border Background="#FF181818" BorderBrush="#FF2A2A2A" BorderThickness="1" CornerRadius="8" Padding="10,8" Margin="0,8,0,0">
          <StackPanel x:Name="HelpPanel"/>
        </Border>

        <TextBlock Style="{StaticResource Hdr}" Text="3. YOUR CAR"/>
        <ComboBox x:Name="VinBox" IsEnabled="False" Height="26"/>
        <TextBlock Style="{StaticResource Hint}" Text="Filled in from your Tessie account after the token checks out."/>

        <TextBlock Style="{StaticResource Hdr}" Text="4. ELECTRICITY RATES ($ per kWh)"/>
        <StackPanel Orientation="Horizontal">
          <TextBlock Text="Preset:" VerticalAlignment="Center" Margin="0,0,8,0"/>
          <ComboBox x:Name="PresetBox" Width="300" Height="26">
            <ComboBoxItem Content="Custom (type my own rates)" IsSelected="True"/>
            <ComboBoxItem Content="Example: PSO RSEV, Oklahoma (Van's plan)"/>
          </ComboBox>
        </StackPanel>
        <Grid Margin="0,8,0,0">
          <Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Grid.Row="0" Text="Overnight rate" VerticalAlignment="Center"/>
          <TextBox x:Name="OnRate" Grid.Row="0" Grid.Column="1" Text="0.10"/>
          <TextBlock Grid.Row="1" Text="Overnight hours (24h)" VerticalAlignment="Center"/>
          <StackPanel Grid.Row="1" Grid.Column="1" Orientation="Horizontal">
            <TextBox x:Name="OnStart" Width="50" Text="23"/><TextBlock Text="  to  " VerticalAlignment="Center"/><TextBox x:Name="OnEnd" Width="50" Text="6"/>
          </StackPanel>
          <TextBlock Grid.Row="2" Text="Daytime rate" VerticalAlignment="Center"/>
          <TextBox x:Name="DayRate" Grid.Row="2" Grid.Column="1" Text="0.13"/>
          <TextBlock Grid.Row="3" Text="Fuel / FCA adder" VerticalAlignment="Center"/>
          <TextBox x:Name="FuelRate" Grid.Row="3" Grid.Column="1" Text="0.00"/>
          <TextBlock Grid.Row="4" Text="Charging efficiency %" VerticalAlignment="Center"/>
          <TextBox x:Name="EffBox" Grid.Row="4" Grid.Column="1" Text="90"/>
        </Grid>
        <TextBlock Style="{StaticResource Hint}" Text="Fuel/FCA adder is the per-kWh fuel charge on your bill, added to every kWh. Efficiency: wall energy lost while charging (90% is typical at home)."/>
        <CheckBox x:Name="PeakOn" Content="I also have a peak (expensive) window" Foreground="#FFDDDDDD" Margin="0,8,0,0"/>
        <Grid x:Name="PeakGrid" Margin="0,4,0,0" IsEnabled="False">
          <Grid.ColumnDefinitions><ColumnDefinition Width="170"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Grid.Row="0" Text="Peak rate" VerticalAlignment="Center"/>
          <TextBox x:Name="PkRate" Grid.Row="0" Grid.Column="1" Text="0.25"/>
          <TextBlock Grid.Row="1" Text="Peak hours, weekdays" VerticalAlignment="Center"/>
          <StackPanel Grid.Row="1" Grid.Column="1" Orientation="Horizontal">
            <TextBox x:Name="PkStart" Width="50" Text="14"/><TextBlock Text="  to  " VerticalAlignment="Center"/><TextBox x:Name="PkEnd" Width="50" Text="19"/>
          </StackPanel>
          <TextBlock Grid.Row="2" Text="Peak months" VerticalAlignment="Center"/>
          <TextBox x:Name="PkMonths" Grid.Row="2" Grid.Column="1" Text="6-10"/>
        </Grid>
        <TextBlock Style="{StaticResource Hdr}" Text="5. TIRE REMINDERS (optional)"/>
        <CheckBox x:Name="RemOn" Content="Let &quot;Remind me to get air&quot; send me reminders" Foreground="#FFDDDDDD"/>
        <TextBlock x:Name="RemOffNote" Style="{StaticResource Hint}" Text="" Foreground="#FFFFB020"/>
        <Grid x:Name="RemGrid" Margin="0,6,0,0" IsEnabled="False">
          <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Grid.Row="0" Text="Send by" VerticalAlignment="Center"/>
          <ComboBox x:Name="RemChannel" Grid.Row="0" Grid.Column="1" Height="26" Margin="0,2,0,0">
            <ComboBoxItem Content="Email (recommended, most reliable)" IsSelected="True"/>
            <ComboBoxItem Content="Text message (carrier gateway)"/>
            <ComboBoxItem Content="Both"/>
          </ComboBox>
          <TextBlock Grid.Row="1" Text="Your email" VerticalAlignment="Center"/>
          <TextBox x:Name="RemEmail" Grid.Row="1" Grid.Column="1"/>
          <TextBlock Grid.Row="2" Text="Mobile number" VerticalAlignment="Center"/>
          <TextBox x:Name="RemPhone" Grid.Row="2" Grid.Column="1"/>
          <TextBlock Grid.Row="3" Text="Carrier" VerticalAlignment="Center"/>
          <ComboBox x:Name="RemCarrier" Grid.Row="3" Grid.Column="1" Height="26" Margin="0,2,0,0"/>
          <TextBlock x:Name="CarrierNote" Grid.Row="4" Grid.Column="1" Style="{StaticResource Hint}"/>
          <TextBlock Grid.Row="5" Text="Send from" VerticalAlignment="Center"/>
          <ComboBox x:Name="SmtpPreset" Grid.Row="5" Grid.Column="1" Height="26" Margin="0,2,0,0"/>
          <TextBlock Grid.Row="6" Text="SMTP server : port" VerticalAlignment="Center"/>
          <StackPanel Grid.Row="6" Grid.Column="1" Orientation="Horizontal">
            <TextBox x:Name="SmtpHost" Width="230"/><TextBlock Text=" : " VerticalAlignment="Center"/><TextBox x:Name="SmtpPort" Width="55"/>
          </StackPanel>
          <TextBlock Grid.Row="7" Text="Sending account" VerticalAlignment="Center"/>
          <TextBox x:Name="SmtpUser" Grid.Row="7" Grid.Column="1"/>
          <TextBlock Grid.Row="8" Text="App Password" VerticalAlignment="Center"/>
          <PasswordBox x:Name="SmtpPass" Grid.Row="8" Grid.Column="1" Padding="4,3" Margin="0,2,0,0"/>
          <TextBlock x:Name="SmtpNote" Grid.Row="9" Grid.Column="1" Style="{StaticResource Hint}"/>
        </Grid>
        <TextBlock Style="{StaticResource Hint}" Margin="0,4,0,0" Text="Reminders go out from YOUR email account (Gmail + App Password is easiest). Texts use your carrier's free email-to-text gateway, and carriers are shutting these down: AT&amp;T no longer delivers, T-Mobile is unreliable, Verizon works until Mar 2027. Email, with mail notifications on your phone, is the reliable choice. The App Password is stored only on this PC, encrypted with Windows DPAPI. Windows Task Scheduler sends each reminder at the time you pick, even if TessDesk is closed (you must be signed in to Windows)."/>
        <StackPanel Orientation="Horizontal" Margin="0,6,0,0">
          <Button x:Name="TestRemBtn" Content="Send test reminder" Width="150" Height="26" IsEnabled="False"/>
          <TextBlock x:Name="TestRemStatus" Style="{StaticResource Hint}" VerticalAlignment="Center" Margin="10,0,0,0" Width="300"/>
        </StackPanel>
        <TextBlock Style="{StaticResource Hdr}" Text="6. CONNECTED APPS · ALEXA ANNOUNCEMENTS (optional)"/>
        <TextBlock Style="{StaticResource Hint}" Text="Tessie is connected above (token + Check). Voice Monkey lets your Echo announce control results and scheduled updates (charging cost, tires, vehicle status). Needs: the Voice Monkey skill enabled in the Alexa app, a Speaker device created in the Voice Monkey dashboard, and an API token. Schedules are picked later in the widget (clock button next to the ALEXA switch)."/>
        <CheckBox x:Name="AnnOn" Margin="0,6,0,0" Foreground="#FFDDDDDD"><TextBlock x:Name="AnnDisc" TextWrapping="Wrap" Width="520"/></CheckBox>
        <Grid x:Name="AnnGrid" Margin="0,6,0,0" IsEnabled="False">
          <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
          <Grid.RowDefinitions><RowDefinition/><RowDefinition/></Grid.RowDefinitions>
          <TextBlock Grid.Row="0" Text="Voice Monkey API token" VerticalAlignment="Center"/>
          <PasswordBox x:Name="VmTok" Grid.Row="0" Grid.Column="1" Padding="4,3" Margin="0,2,0,0"/>
          <TextBlock Grid.Row="1" Text="Speaker device ID" VerticalAlignment="Center"/>
          <TextBox x:Name="VmDev" Grid.Row="1" Grid.Column="1"/>
        </Grid>
        <StackPanel Orientation="Horizontal" Margin="0,6,0,0">
          <Button x:Name="VmCheckBtn" Content="Check" Width="70" Height="26" IsEnabled="False"/>
          <Button x:Name="VmTestBtn" Content="Send test announcement" Width="170" Height="26" Margin="6,0,0,0" IsEnabled="False"/>
          <TextBlock x:Name="VmStatus" Style="{StaticResource Hint}" VerticalAlignment="Center" Margin="10,0,0,0" Width="270" TextWrapping="Wrap"/>
        </StackPanel>
        <StackPanel x:Name="VmLinks" Margin="0,4,0,0"/>
        <TextBlock x:Name="InstallTo" Style="{StaticResource Hint}" Margin="0,12,0,0"/>
      </StackPanel>
    </ScrollViewer>
  </DockPanel>
  </Grid>
</Window>
'@
    $win = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $fx))
    $f = @{}
    foreach ($n in 'NameBox', 'TokBox', 'CheckBtn', 'TokStatus', 'VinBox', 'PresetBox', 'OnRate', 'OnStart', 'OnEnd', 'DayRate', 'FuelRate', 'EffBox',
                   'PeakOn', 'PeakGrid', 'PkRate', 'PkStart', 'PkEnd', 'PkMonths', 'InstallTo', 'Msg', 'InstallBtn', 'CancelBtn',
                   'NoticePage', 'FormPage', 'NoticeTitle', 'NoticeBody', 'AgreeChk', 'PermRead', 'PermCmd', 'PermRem', 'NoticeMsg', 'NoticeCancel', 'ContinueBtn', 'HelpPanel',
                   'RemOn', 'RemOffNote', 'RemGrid', 'RemChannel', 'RemEmail', 'RemPhone', 'RemCarrier', 'CarrierNote', 'SmtpPreset', 'SmtpHost', 'SmtpPort', 'SmtpUser', 'SmtpPass', 'SmtpNote',
                   'TestRemBtn', 'TestRemStatus', 'AnnOn', 'AnnDisc', 'AnnGrid', 'VmTok', 'VmDev', 'VmCheckBtn', 'VmTestBtn', 'VmStatus', 'VmLinks') { $f[$n] = $win.FindName($n) }
    # --- v4.2 Connected apps: Voice Monkey (Alexa) ---
    $f.AnnDisc.Text = 'Set up Alexa announcements. ' + $AnnDisclosure
    $f.AnnOn.Add_Click({ $on = [bool]$f.AnnOn.IsChecked; $f.AnnGrid.IsEnabled = $on; $f.VmCheckBtn.IsEnabled = $on; $f.VmTestBtn.IsEnabled = $on })
    foreach ($l in @(@('Sign up for Voice Monkey', 'https://voicemonkey.io'), @('Enable the Voice Monkey skill in the Alexa app', 'https://www.amazon.com/dp/B08C6Z4C3R'), @('Voice Monkey dashboard: create a Speaker device', 'https://app.voicemonkey.io'), @('Voice Monkey dashboard: API tokens', 'https://app.voicemonkey.io/tokens'))) {
        $tb = New-Object System.Windows.Controls.TextBlock; $tb.FontSize = 11; $tb.Margin = '0,1,0,0'
        $hl = New-Object System.Windows.Documents.Hyperlink; [void]$hl.Inlines.Add($l[0]); $hl.NavigateUri = [Uri]$l[1]; $hl.Foreground = '#FF49DF93'
        $hl.Add_RequestNavigate({ param($s1, $e1) if (-not $GuiSelfTest) { try { Start-Process $e1.Uri.AbsoluteUri } catch {} } })
        [void]$tb.Inlines.Add($hl); [void]$f.VmLinks.Children.Add($tb)
    }
    $f.VmCheckBtn.Add_Click({ try { $f.VmStatus.Text = 'Checking…'; $win.Dispatcher.Invoke([action]{}, 'Background'); $f.VmStatus.Text = '✓ ' + (Test-VoiceMonkey $f.VmTok.Password.Trim() $f.VmDev.Text.Trim()); $f.VmStatus.Foreground = '#FF2ECC40' } catch { $f.VmStatus.Text = '✗ ' + $_.Exception.Message; $f.VmStatus.Foreground = '#FFE82127' } })
    $f.VmTestBtn.Add_Click({ try { $f.VmStatus.Text = '✓ ' + (Invoke-TestAnnouncement $f.VmTok.Password.Trim() $f.VmDev.Text.Trim() ([bool]$DryRun)); $f.VmStatus.Foreground = '#FF2ECC40' } catch { $f.VmStatus.Text = '✗ ' + $_.Exception.Message; $f.VmStatus.Foreground = '#FFE82127' } })
    # --- page 1: notice + permissions ---
    $f.NoticeTitle.Text = $NoticeTitle; $f.NoticeBody.Text = $NoticeText
    $chkNotice = { $f.ContinueBtn.IsEnabled = ([bool]$f.AgreeChk.IsChecked -and [bool]$f.PermRead.IsChecked) }
    $f.AgreeChk.Add_Click($chkNotice); $f.PermRead.Add_Click($chkNotice)
    $f.NoticeCancel.Add_Click({ $win.Close() })
    $f.ContinueBtn.Add_Click({
        $script:FormConsent = New-ConsentRecord ([bool]$f.PermCmd.IsChecked) ([bool]$f.PermRem.IsChecked) 'setup'
        $f.NoticePage.Visibility = 'Collapsed'; $f.FormPage.Visibility = 'Visible'
        if (-not [bool]$f.PermRem.IsChecked) { $f.RemOn.IsChecked = $false; $f.RemOn.IsEnabled = $false; $f.RemGrid.IsEnabled = $false; $f.TestRemBtn.IsEnabled = $false; $f.RemOffNote.Text = 'Off: you did not allow reminders on the notice page.' }
        else { $f.RemOn.IsEnabled = $true; $f.RemOffNote.Text = '' }
    })
    # --- getting started / don't have these yet? (small link buttons, one line each) ---
    $hh = New-Object System.Windows.Controls.TextBlock; $hh.Text = "GETTING STARTED · DON'T HAVE THESE YET?"; $hh.FontWeight = 'Bold'; $hh.FontSize = 11; $hh.Foreground = '#FFAAAAAA'; $hh.Margin = '0,0,0,4'
    [void]$f.HelpPanel.Children.Add($hh)
    foreach ($l in $HelpLinks) {
        $row = New-Object System.Windows.Controls.DockPanel; $row.Margin = '0,2,0,2'
        $b = New-Object System.Windows.Controls.Button; $b.Content = $l[0]; $b.FontSize = 11; $b.Width = 165; $b.Height = 22; $b.HorizontalContentAlignment = 'Left'; $b.Padding = '6,0,6,0'
        $b.Tag = $l[1]; $b.ToolTip = $l[1]; $b.Cursor = [System.Windows.Input.Cursors]::Hand
        $b.Add_Click({ param($s2, $e2) try { Start-Process ([string]$s2.Tag) } catch {} })
        [System.Windows.Controls.DockPanel]::SetDock($b, 'Left'); [void]$row.Children.Add($b)
        $d = New-Object System.Windows.Controls.TextBlock; $d.Text = $l[2]; $d.FontSize = 11; $d.Foreground = '#FF9A9A9A'; $d.TextWrapping = 'Wrap'; $d.Margin = '8,0,0,0'; $d.VerticalAlignment = 'Center'
        [void]$row.Children.Add($d); [void]$f.HelpPanel.Children.Add($row)
    }
    # --- reminders ---
    foreach ($k in $Carriers.Keys) { [void]$f.RemCarrier.Items.Add($Carriers[$k][0] + '  (' + $Carriers[$k][1] + ')') }
    [void]$f.RemCarrier.Items.Add('Other: type the gateway domain in the number box after a space')
    foreach ($k in $SmtpPresets.Keys) { [void]$f.SmtpPreset.Items.Add($SmtpPresets[$k][0]) }
    $script:CarrierKeys = @($Carriers.Keys); $script:PresetKeys = @($SmtpPresets.Keys)
    $f.RemCarrier.Add_SelectionChanged({ $i = $f.RemCarrier.SelectedIndex; if ($i -ge 0 -and $i -lt $script:CarrierKeys.Count) { $f.CarrierNote.Text = $Carriers[$script:CarrierKeys[$i]][2] } else { $f.CarrierNote.Text = 'Example: 5555550100 vtext.com' } })
    $f.SmtpPreset.Add_SelectionChanged({ $i = $f.SmtpPreset.SelectedIndex; if ($i -ge 0) { $ps = $SmtpPresets[$script:PresetKeys[$i]]; $f.SmtpHost.Text = $ps[1]; $f.SmtpPort.Text = [string]$ps[2]; $f.SmtpNote.Text = $ps[3] } })
    $f.RemCarrier.SelectedIndex = 0; $f.SmtpPreset.SelectedIndex = 0
    $f.RemEmail.Add_LostFocus({ if (-not $f.SmtpUser.Text -and $f.RemEmail.Text -match '@') { $f.SmtpUser.Text = $f.RemEmail.Text.Trim() } })
    $f.RemOn.Add_Click({ $on = [bool]$f.RemOn.IsChecked; $f.RemGrid.IsEnabled = $on; $f.TestRemBtn.IsEnabled = $on })
    $script:GetFormRem = {
        $on = [bool]$f.RemOn.IsChecked
        $ch = @('email', 'text', 'both')[[math]::Max(0, $f.RemChannel.SelectedIndex)]
        $ci = $f.RemCarrier.SelectedIndex; $ck = ''; $gw = ''; $phone = $f.RemPhone.Text.Trim()
        if ($ci -ge 0 -and $ci -lt $script:CarrierKeys.Count) { $ck = $script:CarrierKeys[$ci] } elseif ($phone -match '^\s*([\d\-\(\) \+\.]+?)\s+([a-z0-9\.\-]+\.[a-z]{2,})\s*$') { $phone = $Matches[1]; $gw = $Matches[2]; $ck = 'other' }
        $port = 0; [void][int]::TryParse($f.SmtpPort.Text, [ref]$port)
        return (New-ReminderConfig $on $ch $f.RemEmail.Text.Trim() $phone $ck $gw $script:PresetKeys[[math]::Max(0, $f.SmtpPreset.SelectedIndex)] $f.SmtpHost.Text.Trim() $port $f.SmtpUser.Text.Trim() ([bool]$ReminderDryRun))
    }
    $f.TestRemBtn.Add_Click({
        try {
            $rem = & $script:GetFormRem; $rem.enabled = $true
            Test-ReminderConfig $rem ([bool]$f.SmtpPass.Password)
            $f.TestRemStatus.Text = $(if ($DryRun) { 'Composing (dry run, nothing is sent)…' } else { 'Sending…' }); $f.TestRemStatus.Foreground = 'Gray'
            $win.Dispatcher.Invoke([action]{}, 'Background')
            $res = Invoke-TestReminder $rem $f.SmtpPass.Password ([bool]$DryRun)
            if ($DryRun) { [System.Windows.MessageBox]::Show(($res.lines -join "`n"), 'TessDesk · Test reminder (dry run)') | Out-Null }
            if ($res.ok) { $f.TestRemStatus.Text = $(if ($DryRun) { '✓ Dry run OK (nothing sent)' } else { '✓ Sent. Check your inbox / phone.' }); $f.TestRemStatus.Foreground = '#FF2ECC40' }
            else { $f.TestRemStatus.Text = '✗ ' + (@($res.lines | Where-Object { $_ -match 'FAILED|not' }) | Select-Object -Last 1); $f.TestRemStatus.Foreground = '#FFE82127' }
        } catch { $f.TestRemStatus.Text = '✗ ' + $_.Exception.Message; $f.TestRemStatus.Foreground = '#FFE82127' }
    })
    $f.NameBox.Text = [Environment]::UserName
    $f.InstallTo.Text = 'Installs to ' + $InstallDir + (' (Desktop + Startup shortcuts).')
    if ($DryRun) { $f.InstallBtn.Content = 'Dry run (no changes)' }
    $script:FormVehicles = @()

    $f.PeakOn.Add_Click({ $f.PeakGrid.IsEnabled = [bool]$f.PeakOn.IsChecked })
    $f.PresetBox.Add_SelectionChanged({
        if ($f.PresetBox.SelectedIndex -eq 1) {
            $f.OnRate.Text = '0.030451'; $f.OnStart.Text = '23'; $f.OnEnd.Text = '6'; $f.DayRate.Text = '0.061045'; $f.FuelRate.Text = '0.031872'
            $f.PeakOn.IsChecked = $true; $f.PeakGrid.IsEnabled = $true; $f.PkRate.Text = '0.248475'; $f.PkStart.Text = '14'; $f.PkEnd.Text = '19'; $f.PkMonths.Text = '6-10'
            $f.Msg.Text = 'PSO RSEV example loaded (daytime is 0.084497 in Jun-Oct, 0.061045 Nov-May).'
        }
    })
    $f.CheckBtn.Add_Click({
        $f.TokStatus.Text = 'Checking with Tessie…'; $f.TokStatus.Foreground = 'Gray'
        $win.Dispatcher.Invoke([action]{}, 'Background')
        try {
            $vs = @(Get-TessieVehicles $f.TokBox.Password.Trim())
            if ($vs.Count -eq 0) { throw 'Token works, but no cars were found on this Tessie account.' }
            $script:FormVehicles = $vs
            $f.VinBox.Items.Clear(); foreach ($v in $vs) { [void]$f.VinBox.Items.Add($v.label) }
            $f.VinBox.SelectedIndex = 0; $f.VinBox.IsEnabled = $true
            $f.TokStatus.Text = ('✓ Token OK · {0} car(s) found' -f $vs.Count); $f.TokStatus.Foreground = '#FF2ECC40'
            $f.InstallBtn.IsEnabled = $true
        } catch {
            $f.TokStatus.Text = '✗ ' + $_.Exception.Message; $f.TokStatus.Foreground = '#FFE82127'
            $f.InstallBtn.IsEnabled = $false
        }
    })
    $f.CancelBtn.Add_Click({ $win.Close() })
    $f.InstallBtn.Add_Click({
        try {
            $num = { param($t, $label) $d = 0.0; if (-not [double]::TryParse(($t -replace ',', '.'), [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { throw "$label must be a number" }; $d }
            if ($f.PresetBox.SelectedIndex -eq 1) { $rates = $PsoPreset }
            else {
                $rates = New-CustomRates (& $num $f.OnRate.Text 'Overnight rate') ([int](& $num $f.OnStart.Text 'Overnight start')) ([int](& $num $f.OnEnd.Text 'Overnight end')) `
                    (& $num $f.DayRate.Text 'Daytime rate') (& $num $f.FuelRate.Text 'Fuel adder') ([bool]$f.PeakOn.IsChecked) `
                    (& $num $f.PkRate.Text 'Peak rate') ([int](& $num $f.PkStart.Text 'Peak start')) ([int](& $num $f.PkEnd.Text 'Peak end')) $f.PkMonths.Text
            }
            $eff = & $num $f.EffBox.Text 'Efficiency'
            if ($eff -lt 50 -or $eff -gt 100) { throw 'Efficiency should be between 50 and 100 %' }
            $vin = $script:FormVehicles[$f.VinBox.SelectedIndex].vin
            $rem = & $script:GetFormRem
            $ann = $null
            if ([bool]$f.AnnOn.IsChecked) {
                if (-not $f.VmTok.Password.Trim() -or -not $f.VmDev.Text.Trim()) { throw 'Alexa: enter the Voice Monkey token and speaker device, or untick the Alexa box.' }
                $ann = [ordered]@{ token = $f.VmTok.Password.Trim(); device = $f.VmDev.Text.Trim() }; $script:FormConsent.announcements = $true
            } else { $script:FormConsent.announcements = $false }
            $out = Install-TessDesk $f.NameBox.Text.Trim() $f.TokBox.Password.Trim() $vin $rates $eff $script:FormConsent $rem $f.SmtpPass.Password $ann
            [System.Windows.MessageBox]::Show(($out -join "`n"), 'TessDesk Setup') | Out-Null
            $win.Close()
        } catch { $f.Msg.Text = '✗ ' + $_.Exception.Message; $f.Msg.Foreground = '#FFE82127' }
    })
    if ($GuiSelfTest) { $c = 0; foreach ($k in $f.Keys) { if ($null -ne $f[$k]) { $c++ } }; Write-Step ("GUI self-test: form built, {0}/{1} controls found" -f $c, $f.Count); $win.Close(); return }
    [void]$win.ShowDialog()
}

# ---------------- Main ----------------
Write-Step ("TessDesk Setup v{0}  ·  install folder: {1}{2}" -f $SetupVersion, $InstallDir, $(if ($DryRun) { '  ·  DRY RUN' } else { '' }))
if ($GuiSelfTest -or -not $NoGui) {
    try { Show-SetupForm } catch { Write-Step ('Setup error: ' + $_.Exception.Message); try { [System.Windows.MessageBox]::Show($_.Exception.Message, 'TessDesk Setup') | Out-Null } catch {}; exit 1 }
    exit 0
}

# -NoGui path (scripted installs / testing)
try {
    $smtpPw = ''
    if ($SmtpPasswordFile) { $smtpPw = Read-SecretFile $SmtpPasswordFile }
    $remOn = ([bool]$AllowReminders -and ([bool]$RemindEmail -or [bool]$RemindPhone))
    $remCfg = New-ReminderConfig $remOn $RemindChannel $RemindEmail $RemindPhone $Carrier '' $SmtpPreset $SmtpHost $SmtpPort $SmtpUser ([bool]$ReminderDryRun)
    if ($TestReminder) {
        $remCfg.enabled = $true
        Test-ReminderConfig $remCfg ([bool]$smtpPw -or [bool]$DryRun)
        Write-Step $(if ($DryRun) { 'Test reminder (DRY RUN: composed and printed, nothing is sent):' } else { 'Sending test reminder…' })
        $res = Invoke-TestReminder $remCfg $smtpPw ([bool]$DryRun)
        foreach ($l in $res.lines) { Write-Step $l }
        if ($res.ok) { exit 0 } else { exit 1 }
    }
    $ann = $null
    if ($AllowAnnouncements -or $TestAnnouncement) {
        $vmTok = ''; if ($VoiceMonkeyTokenFile) { $vmTok = Read-SecretFile $VoiceMonkeyTokenFile }
        if ($TestAnnouncement) { Write-Step (Invoke-TestAnnouncement $vmTok $VoiceMonkeyDevice ([bool]$DryRun)); exit 0 }
        if ($vmTok -and $VoiceMonkeyDevice) { $ann = [ordered]@{ token = $vmTok; device = $VoiceMonkeyDevice } } else { Write-Step 'Alexa: -VoiceMonkeyTokenFile and -VoiceMonkeyDevice are both needed; skipping announcements.' }
    }
    if (-not $AcceptTerms) {
        Write-Step $NoticeTitle
        foreach ($l in ($NoticeText -split "`r?`n")) { Write-Step $l }
        throw 'Pass -AcceptTerms to agree to the notice above (add -AllowCommands / -AllowReminders for the optional permissions).'
    }
    $consent = New-ConsentRecord ([bool]$AllowCommands) ([bool]$AllowReminders) 'setup-nogui' ([bool]$AllowAnnouncements -and $null -ne $ann)
    if (-not $Name) { $Name = [Environment]::UserName }
    $secret = Read-SecretFile $TokenFile
    if (-not $secret) { throw 'Pass -TokenFile <file containing your Tessie API token>.' }
    if ($SkipValidation) {
        Write-Step 'Skipping Tessie validation (-SkipValidation).'
        if (-not $Vin) { throw 'With -SkipValidation you must pass -Vin.' }
    } else {
        $vs = @(Get-TessieVehicles $secret)
        if ($vs.Count -eq 0) { throw 'Token works, but no cars were found on this Tessie account.' }
        Write-Step ('Token OK · {0} car(s): {1}' -f $vs.Count, (($vs | ForEach-Object { $_.label }) -join ' | '))
        if (-not $Vin) { $Vin = $vs[0].vin }
        elseif (-not ($vs | Where-Object { $_.vin -eq $Vin })) { throw "VIN $Vin is not on this Tessie account." }
    }
    if ($Preset -eq 'pso') { $rates = $PsoPreset }
    else { $rates = New-CustomRates $OvernightRate $OvernightStart $OvernightEnd $DaytimeRate $FuelAdder ([bool]$PeakEnabled) $PeakRate $PeakStart $PeakEnd $PeakMonths }
    foreach ($l in (Install-TessDesk $Name $secret $Vin $rates $EfficiencyPct $consent $remCfg $smtpPw $ann)) { Write-Step $l }
    Write-Step 'Done.'
} catch { Write-Step ('FAILED: ' + $_.Exception.Message); exit 1 }
