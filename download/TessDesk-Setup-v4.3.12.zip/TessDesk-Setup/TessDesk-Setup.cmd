@echo off
rem TessDesk Setup - double-click to install
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0TessDesk-Setup.ps1" %*
if errorlevel 1 pause
