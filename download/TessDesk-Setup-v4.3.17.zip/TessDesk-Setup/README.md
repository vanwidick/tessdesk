# TessDesk v4.3.17 Setup

TessDesk is a small always-on-top desktop widget for Windows that shows what your Tesla's charging is costing you, live: the current session in dollars and ¢/kWh, battery % and range with a charge bar, charging power (kW, volts, amps), time to full, tire pressures in green / yellow / red (red flashes) with a **Remind me to get air** button, Tonight / Last 7 days / Last 30 days totals, and **Tesla controls** (lock, windows, climate, temperature, charge limit). It gets its data from your **Tessie** account (https://tessie.com).

**Phone version:** TessDesk also runs on your phone in the browser at **https://vanwidick.github.io/tessdesk/**. Open it in Safari or Chrome and use *Add to Home Screen*.

## New in v4.3.17 (Oct 8, 2026)

- **New layout: controls first.** TESLA CONTROLS (with LEAVING SOON, the Windows after / Unlock after waits and every control button) now sits right under the big charging amount and the 7 / 14 / 30 / 60 DAYS amounts. START CHARGING / STOP CHARGING come next, then the battery (charge % and range, the limit slider), CHARGING AMPS, the POWER / DURATION / ENDED tiles and the day-rate line.
- **CHARGE HISTORY & TOTALS dropdown.** Last night, Last 7 days, Last 30 days and the TOTALS row are folded into one row below that, showing last night's cost while closed. Click it to open or close it; TessDesk remembers your choice (config.json ui.historyOpen). The TOTALS pop-up works as before. Desktop only.

## New in v4.3.16 (Oct 5, 2026)

- **Leaving Soon waits you choose.** Under the LEAVING SOON button, *Windows after* and *Unlock after* set the minutes (0-30, default 3) with - / + buttons, the mouse wheel or Up / Down. TessDesk remembers them (config.json). The countdown and the Alexa announcements use your times, and 0 means that step happens right away.
- **Stop now undoes what Leaving Soon already did.** When Leaving Soon starts, TessDesk notes how the car was (from Tessie's cached data, without waking it). If you press Stop partway through, the remaining steps are cancelled and only the steps already done are reversed: climate goes back off if it was off, the windows are vented if any were open (Tessie can only vent or close them), and the car is locked again if it was locked. Each undo step is announced on Alexa and shown as "Undoing 1 of 2". Desktop only.

## New in v4.3.15 (Oct 4, 2026)

- **LEAVING SOON button.** Next to the TESLA CONTROLS heading, above Flash Lights. It asks first, then announces on Alexa that Leaving Soon is starting, turns on climate, closes the windows 3 minutes later and unlocks the car 3 minutes after that, announcing each step. The widget shows the step and a countdown (for example "Step 2 of 3 · closing windows in 2:41") with a STOP button that cancels the rest and announces the cancel. If a step fails it is shown in red, announced, and the remaining steps do not run. Desktop only.

## New in v4.3.14 (Oct 4, 2026)

- **14 days and 60 days added beside the big amount.** Under the 7 DAYS amount on the left you now see what the last 14 days cost, and under the 30 DAYS amount on the right the last 60 days. Money only, same look, same math as the Last 7 days and Last 30 days rows (home charging plus what you paid at Superchargers, charges counted by the day they started). The big charging amount stays centered and the two sides stay even. TessDesk now reads 60 days of charge history from Tessie for this. Same on the phone app.

## New in v4.3.13 (Oct 4, 2026)

- **Rolling 7 days and 30 days, right next to the big amount.** The big charging amount at the top stays centered. On its left you now see what the last 7 days cost, and on its right the last 30 days, each with a small 7 DAYS / 30 DAYS caption and just the dollar figure. They use the same math as the Last 7 days and Last 30 days rows (home charging plus what you paid at Superchargers, charges counted by the day they started), so the numbers always match, and they refresh with the rest of TessDesk. Same on the phone app.

## New in v4.3.12 (Oct 4, 2026)

- **Restore / Remember moved to the top right, like Paycheck Live.** The two buttons now sit at the top right under the title bar, in the same spot as in Paycheck Live. They fade in when you move the mouse over TessDesk and hide again 2.2 s after the mouse stops (not while the mouse is on them). The Charging / Updated status moved to its own line just below them so nothing overlaps. SHARE stays in the footer. What the buttons do is unchanged.

## New in v4.3.11 (Oct 4, 2026)

- **Restore / Remember look like Paycheck Live's.** The two buttons under the footer now use the same small dark pills as Paycheck Live (Segoe UI, gray #444 with light text, lighter on mouse-over), in the same order (Restore, then Remember). After a click the button reads restored / saved (or failed) for a moment and its tooltip shows the spot. What they do is unchanged: Remember saves TessDesk's spot in desk_window_layout.json (TESSDESK entry), Restore moves it back.

## New in v4.3.10 (Oct 3, 2026)

- **TOTALS pop-up.** A $ TOTALS button under Last 30 days opens running totals for this week (Monday to Sunday), this month and this year: kWh, cost, charging nights and average cents per kWh, plus a month-by-month list (click a month to see each night). Home totals count only charging at 3515 W 41st Pl at the all-in PSO rate; Supercharger charging is listed separately with the amount Tessie reports as paid, and both go into a grand total.
- **Fast to open.** The charge history is saved in totals-cache.json next to TessDesk, so the list opens right away; Refresh reloads the year with a count and a Stop button. Close with X or Esc.
- **Desktop and phone match.** Last 7 / 30 days and the totals use one shared rule on both (whole charges that started in the period).

## New in v4.3.9 (Oct 3, 2026)

- **CAMERAS panel.** A camera On / Off switch in the title bar adds a panel at the top, above the charging amount: Front, Rear, Left and Right repeater tabs and a 4-up grid. It is not live: Tesla and Tessie don't offer a live camera feed, so TessDesk loops still frames from your saved Sentry and Dashcam clips (the TeslaCam folder copied to the PC, or a Wi-Fi USB drive; pick it in Camera options). Off by default.
- **Capture.** Each camera has a Capture button: the frame is saved in Pictures\TessDesk Captures and an email to vanwidick@gmail.com opens with it (sent for you if email is set up in Setup > Reminders).
- **Full screen** grid with a layout choice (two monitors: Front on one, the rest on the other; or one screen). Esc or X closes it, and the always-on-top window steps aside while it is open.
- **Save clip** copies the selected Sentry clip to Videos\TessDesk Clips, with a count and Stop.

## New in v4.3.8 (Oct 3, 2026)

- **Checks for updates every time TessDesk opens or the PC turns on/wakes.** TessDesk now looks for a new version right away each time it starts (including the auto-start when the PC boots), when the PC wakes from sleep, and when you bring the window back (restore or click on it, at most once every 5 minutes). The check about every 3 hours stays. If the network isn't up yet after a boot or wake, it quietly tries again a few times over about 2 minutes.
- **Later means later.** If you press Later on the Update now / Later pop-up, TessDesk won't ask again about that version until the next time it opens (the green UPDATE button stays).

## New in v4.3.7 (Oct 3, 2026)

- **REMEMBER / RESTORE use desk_window_layout.json**, the same file and behavior as TIMECLOCK LIVE and Paycheck Live (entry TESSDESK; only that entry is ever rewritten). REMEMBER won't save a minimized, maximized or off-screen window; RESTORE goes back to the remembered place, or to the startup place if nothing was remembered. TessDesk opens at the remembered place.
- **Update pop-up.** When a newer version is out, TessDesk asks **Update now / Later**. Update now downloads it, checks every file's SHA-256, backs up your copy and restarts TessDesk where it is. Later asks again the next day (the green UPDATE button stays). TessDesk now checks about every 3 hours.
- **SHARE** (desktop footer and phone footer): Messenger, Text, Email, Copy link and Send to phone (a QR code to scan). Only the TessDesk links are shared, never your token, and nothing is sent until you press send in the app that opens.

## New in v4.3.6 (Oct 3, 2026)

- **KEEP renamed REMEMBER.** The desktop footer buttons now read **REMEMBER / RESTORE**, the same wording as your other windows. They work the same way.
- **Desktop and phone Sessions agree.** Both now use the same rule: finished charges come from Tessie's charge list, the charge in progress comes from the car, and nothing is counted twice (back-to-back parts like 11:00-11:03 and 11:03-2:47 are both kept).

## New in v4.3.5 (Oct 3, 2026)

- **Adjustable flash pause.** Pause between flashes 1-30 s (0.5 s steps; default 1 s, 5 flashes). Under 3 s each flash is sent without waiting for the car; the next one never goes while the last is still in flight. Shows the measured gap and each flash's response time (last / average).
- **Sessions** under Tonight: each charging session of the current or last 11 PM - 11 AM window with its time, kWh and cost.
- **REMEMBER / RESTORE** (desktop; called KEEP in v4.3.5): remember where TessDesk sits and move it back; it opens there next time.

## New in v4.3.4 (Oct 3, 2026)

- **Flash Lights fixed.**

## New in v4.3.3 (Oct 3, 2026)

- **OPEN TRUNK.** Opens the rear trunk after an "Are you sure?" pop-up. If the trunk is already open the button reads TRUNK OPEN and asks before closing it. There is no frunk button.
- **SENTRY MODE.** One on/off button that shows the car's current Sentry state (green when on) and asks before changing it.
- **DRIVES.** A new card after Tires lists your recent drives: date and time, start → end place, miles, kWh used, how long it took and a cost estimate (energy used at your home off-peak rate). Tap a drive to open its route in Google Maps. **Location history** lists where the car has been, each place opens on the map, and **OPEN MAP** shows the recent stops as one route. Read-only, refreshed about every 15 minutes.
- **Updates, one click.** Once a day the widget reads https://vanwidick.github.io/tessdesk/version.json (nothing about you or your car is sent). When a newer version exists a green **UPDATE AVAILABLE · v4.3.x** button appears at the top: one click downloads it, verifies each file's SHA-256, backs up your current copy (backup-v<old>-<time> in the TessDesk folder), installs it and restarts TessDesk. The phone app shows a **New version, tap to refresh** banner.
- **Paused charging is never counted twice.** If charging pauses and resumes on the same plug-in (the car's energy counter keeps running), it stays one session and only the new kWh are added, however long the pause. A counter that restarted is still its own session.

## New in v4.3.2 (Oct 3, 2026)

- **Last charge = the whole night.** Every home charging session from 11 PM to 11 AM the next morning counts as ONE charge (unplug for 30 minutes and plug back in: same charge). kWh after 6 AM are priced at the day rate.
- **Whole-window glow.** Red when the car is not plugged in, solid green when it is plugged in (including charge complete / limit reached), and a slow green pulse (about 3.5 s) while it is actively charging.
- **Flash Lights.** New control between Locked and A/C: pick how many flashes (1-20, default 3), it asks first, shows "Flashing 2 of 5" and has a Stop button.
- **Green outlines** on every control (lock, A/C, Heat, Defrost, Overheat, Vent, Close, temperature - and +, Announce on Alexa, the seats).
- **Heated seats** moved above Tires; a seat turns solid red while its heat is on.

## New in v4.3.1 (Oct 2, 2026)
- **Announce Setup → Speakers (Echos)**: a dropdown of every speaker on your Voice Monkey account with a tick to include each one in announcements and a **▶ Test** button per speaker (plays one short line on that Echo only, only when you click it).
- **+ Add speaker**: type a name (e.g. Kitchen Echo), **Open Voice Monkey · Add New Speaker** opens app.voicemonkey.io/speakers and copies the name, short steps show the one Alexa-app Routine step, then **Refresh list** picks up the new speaker (marked NEW and ticked). Voice Monkey's API can list speakers but cannot create them.
- Fixed the "ALL 1 ECHO" label: it now reads **ALL ECHOS (1)**.

## New in v4.3
- **Always-visible rate status**: a PSO RSEV-style peak/day pill with an extra-cost estimate, a Stop button and a Scheduled Charging tip; a green off-peak pill ("cheapest rate until 6 AM"); a neutral line when idle.
- **Vertical charge-limit slider** next to the battery card.
- **Announce on Alexa**: a spoken rundown (incl. the current rate period) with Setup for the items to read, and **All Echos / pick a speaker / Refresh devices**.

## What you need
- Windows 10 or 11 (Windows PowerShell 5.1 is built in, so nothing else to install)
- A Tessie account with your car linked. **No account yet?** Sign up at https://www.tessie.com. Tessie is a paid service that connects to your Tesla.
- Your Tessie **API token**: https://dash.tessie.com/settings/api (or Tessie app → Settings → API)
- Your electricity rates (from your power bill or your utility's EV rate page)
- Optional, for tire reminders: an email account to send from. **Gmail** is easiest: create one at https://accounts.google.com/signup, turn on 2-Step Verification (https://myaccount.google.com/signinoptions/two-step-verification), then make an **App Password** (https://myaccount.google.com/apppasswords · help: https://support.google.com/accounts/answer/185833).

The token step of Setup and the widget's **About / Privacy** screen both have these links as a **Getting started / Don't have these yet?** panel.

## Notice and permissions
Setup first shows a notice (also in `PRIVACY.md`). TessDesk is unofficial and not affiliated with Tesla or Tessie. It reads vehicle data with your token and sends commands only when you press them. Your token stays on this PC (Windows DPAPI) and is sent only to api.tessie.com. Reminders go through your own email or carrier. Costs are estimates, commands can wake the car, there's no warranty, and Tessie's Terms apply. Tick **I agree**, then choose:
- **Read vehicle data from Tessie** (required)
- **Send vehicle commands** (optional; off = the controls and the charge-limit slider are disabled)
- **Reminders by email/text** (optional)

Your choices are saved with a timestamp in `config.json` (`"consent"`). If you update TessDesk without running Setup, the widget shows the same notice on first start and doesn't contact Tessie until you agree. Click **About / Privacy** in the footer at any time to review the notice or change permissions.

## Where to find your Tessie token
1. Open the **Tessie** app (or https://dash.tessie.com).
2. Go to **Settings → API**.
3. Create or copy the **access token** (a long string of letters and numbers).
4. Paste it into the setup form. Treat it like a password: anyone who has it can read your car's data.

## Install
1. Unzip `TessDesk-Setup-v4.3.2.zip` to a folder (e.g. Downloads\TessDesk-Setup). **Unzip it first.** Running it from inside the zip won't work.
2. Double-click **`TessDesk-Setup.cmd`**.
   - If Windows SmartScreen shows "Windows protected your PC", click **More info → Run anyway**. (The setup is a plain PowerShell script; you can open `TessDesk-Setup.ps1` in Notepad and read it.)
   - If files were blocked after download: right-click the zip → **Properties** → tick **Unblock** → OK, then unzip again.
3. Fill in the form (each field is explained below), click **Check token**, pick your car, then click **Install TessDesk**.
4. TessDesk starts in the top-right corner of your main screen. Desktop and Startup shortcuts named **TessDesk** are created, so it also starts when you sign in.

## The fields
| Field | What it means |
|---|---|
| **Your name** | Shown as "Logged in as …" at the top of the widget. |
| **Tessie API token** | Lets TessDesk read your car's charging data. Hidden while you type. Stored only on your PC in `tessie.token.dpapi`, encrypted with Windows DPAPI so only your Windows account can read it. |
| **Tire reminders (optional)** | *Send by*: Email (recommended), Text, or Both. *Your email* and/or *mobile number + carrier*. *Send from*: your own email account (Gmail + App Password preset; Outlook, Yahoo, iCloud, Custom). The App Password is stored encrypted with DPAPI in `smtp.secret`. Click **Send test reminder** to check it. **Texts** use the carrier's email-to-text gateway, and carriers are shutting these down: AT&T stopped in June 2025, T-Mobile is unreliable, and Verizon works until Mar 31, 2027. Email, with your phone's mail notifications on, is the reliable choice. |
| **Your car** | Filled in from your Tessie account after the token checks out. Pick the car to track. |
| **Preset** | *Custom* = type your own rates. *Example: PSO RSEV* fills in Public Service Company of Oklahoma's EV time-of-use plan (Van's plan) as an example. |
| **Overnight rate** | $ per kWh during your cheap overnight hours, e.g. `0.030451`. |
| **Overnight hours** | Start and end hour in 24-hour time, e.g. `23` to `6` = 11 PM–6 AM. |
| **Daytime rate** | $ per kWh for all other hours. |
| **Fuel / FCA adder** | A per-kWh charge added to *every* kWh (often called fuel cost adjustment, FCA or fuel charge on your bill). Use `0` if you don't have one. |
| **Charging efficiency %** | Share of the energy from the wall that ends up in the battery. 90% is typical for home Level 2 charging. Cost is calculated on wall energy = battery kWh ÷ efficiency. |
| **Peak window (optional)** | If your plan has expensive peak hours: the peak $/kWh, its hours (weekdays) and months, e.g. `6-10` = June–October. |

Every rate is "all-in" per kWh: TessDesk adds the fuel adder to the time-of-use rate for each hour of charging.

## Using TessDesk
- **Look**: always the Tessie-app style, following your car: **green** while charging, **red-tinted** when not.
- **Battery**: current % (large) and range in miles as your car shows it (rated or ideal). The bar runs 0–100%: the ball is where the battery is now, the thin tick is where this charge started (**FROM**), and the white handle is your **LIMIT**.
- **Charge limit**: drag the white LIMIT handle (or click anywhere on the bar). The new % and miles show large while you drag. Let go, then confirm "Set charge limit to 85%?". The car's allowed range (usually 50–100%) is enforced.
- **Tesla controls** (above Tires): Lock/Unlock, Vent / Close windows, A/C on/off, and − / + for the cabin temperature (°F or °C, matching your car). **Unlock** and **Vent** ask for confirmation first. While a command runs you see a spinner, then OK or the error. Commands may wake the car. Normal updates never do.
  To try the buttons without sending anything, set `"controls": { "dryRun": true }` in config.json and restart TessDesk. `"enabled": false` turns the buttons off.
- **Tires**: **green** = good. **Yellow** + LOW/HIGH = a little out (the car's soft TPMS warning, or 5–10% from the car's recommended pressure). **Red** + LOW/HIGH, **flashing** = really out (the car's hard TPMS warning, or more than 10% off). Change the thresholds in config.json: `"tires": { "yellowPct": 5, "redPct": 10, "maxPsiNoRec": 48, "minPsiNoRec": 38 }`.
- **Remind me to get air** (under the tires): pick 1, 2, 4, or 8 hours or a custom number. TessDesk creates a one-time Windows Task Scheduler task ("TessDesk Reminder …") that sends the low tire(s) and their PSI by your chosen channel. It fires even if TessDesk is closed, but only while you're signed in to Windows (if the PC is asleep, it sends when it wakes). Log: `reminders.log`. Set `"reminders": { "dryRun": true }` to compose without sending.
- **Setup: how reminders reach you** (link under the remind button): tick any mix of **Email**, **Text** (carrier email-to-text gateway: AT&T shut down June 2025, T-Mobile unreliable, Verizon until March 2027), **Alexa** (Voice Monkey, after you add it in Settings → Connected apps), **Windows notification** (works right away, no account needed) and **Phone calendar** (an .ics file or Google Calendar link with an alert, created the moment you pick the time). *Send test* sends one test by the ticked channels (respects dry-run). Tessie itself can also alert you: Tessie app → Notifications (bell, top right) → Low tire pressure. The Tessie API cannot push to the Tessie app or show a message on the car screen.
- **FULL / COMPACT** (button in the title bar): Compact shrinks everything to fit your screen height with no scrolling; Full is normal size with scrolling. Your choice is remembered.
- **What's new**: click the version under DESIGN BY VAN to open the changelog.
- **Tonight / Last night**: an "overnight" runs 11 PM–11 AM (starting at your overnight start hour).
- **Live updates**: TessDesk reads Tessie's cached copy of your car's data (fed by Tesla's telemetry, usually seconds old) every **10 s** while charging, driving, climate is on or right after you press a control, every **15 s** while the widget is focused, every **60 s** when idle and **2–5 min** while the car sleeps. A command is followed by a check 4 s later. The badge shows **"Updated Xs ago"** (green when under 30 s). These reads never wake the car. Totals refresh about every 15 minutes.
- Drag the widget to move it. Settings live in `%LOCALAPPDATA%\TessDesk\config.json` (`"defaultTheme": "tessie"` or `"tessdesk"` sets the starting look). Edit it with Notepad and restart TessDesk to change rates or your name.

## Uninstall
Double-click `Uninstall TessDesk.cmd` in `%LOCALAPPDATA%\TessDesk` (paste that path into the File Explorer address bar). It stops TessDesk, removes its reminder tasks and shortcuts, and deletes the folder, including your token and App Password. To revoke access completely, also delete the API token in the Tessie app (Settings → API).

## Advanced (command line)
```
TessDesk-Setup.cmd -DryRun                     # show what would be installed, change nothing
TessDesk-Setup.cmd -NoGui -AcceptTerms -AllowCommands -Name "Alex" -TokenFile C:\path\token.txt -Preset pso
TessDesk-Setup.cmd -NoGui -AcceptTerms -AllowReminders -RemindChannel email -RemindEmail me@gmail.com -SmtpUser me@gmail.com -SmtpPasswordFile C:\path\apppw.txt ...
TessDesk-Setup.cmd -NoGui -TestReminder -DryRun -RemindEmail me@gmail.com -SmtpUser me@gmail.com   # print the test reminder, send nothing
TessDesk-Setup.cmd -InstallDir D:\Apps\TessDesk -NoShortcuts -NoLaunch
```
